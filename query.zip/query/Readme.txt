Cather Zhang czhang10

Section I:

How to execute the project: 
- unzip the file
- in terminal, go to the directory of the src folder (the path should end with \src)
- run command "javac Main.java" to compile
- run command "java Main" to start
- use query commands for functionality, and "exit" to terminate the program

Note:
- all the files are already located in src folder under Project1.


Section II:
Program functions properly

Section III:
- I kept the locations of the records with given RandomV as a single string, each with two characters (ASCII value is file#, record#)
